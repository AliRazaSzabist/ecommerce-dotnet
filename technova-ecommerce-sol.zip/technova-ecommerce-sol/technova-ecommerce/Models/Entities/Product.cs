using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace technova_ecommerce.Models.Entities
{
	[Table("Product")]
	public class Product
	{
		[Column("product_id")]
		[Key]
		[DatabaseGenerated(DatabaseGeneratedOption.Identity)]
		public int ProductId { get; set; }

		[Column("product_name")]
		[Display(Name = "Name")]
		public string ProductName { get; set; }

		[Column("description")]
		[Display(Name = "Description")]
		public string ProductDescription { get; set; }

		[Column("quantity")]
		[Display(Name = "Quantity")]
		public int Quantity { get; set; }

		[Column("price")]
		[Display(Name = "Price")]
		public int Price { get; set; }
	}
}
